Teste do exemplo phaser
